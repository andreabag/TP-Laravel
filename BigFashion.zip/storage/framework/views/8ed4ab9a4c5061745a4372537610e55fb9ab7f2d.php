<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e('Modificar'); ?></div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(url('Modificar')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>


      <div class="form-group row">
          <label for="titulo" class="col-md-4 col-form-label text-md-right"><?php echo e('Título'); ?></label>

          <div class="col-md-6">
              <input id="titulo" type="text" class="form-control <?php if ($errors->has('titulo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('titulo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="titulo" required autocomplete="titulo">

              <?php if ($errors->has('titulo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('titulo'); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
      </div>

      <div class="form-group row">
          <label for="descripcion" class="col-md-4 col-form-label text-md-right"><?php echo e('Descripción'); ?>

          </label>

          <div class="col-md-6">
              <input id="descripcion" type="text" class="form-control <?php if ($errors->has('descripcion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('descripcion'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="descripcion" required autocomplete="descripcion">

              <?php if ($errors->has('descripcion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('descripcion'); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
      </div>

      <div class="form-group row">
          <label for="foto" class="col-md-4 col-form-label text-md-right"><?php echo e('Foto'); ?></label>

          <div class="col-md-6">
              <input id="foto" type="file" class="form-control <?php if ($errors->has('foto')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="titulo" required autocomplete="titulo">

              <?php if ($errors->has('descripcion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('descripcion'); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
      </div>

      <div class="form-group row">
          <label for="precio" class="col-md-4 col-form-label text-md-right"><?php echo e('Precio'); ?></label>

          <div class="col-md-6">
              <input id="precio" type="text" class="form-control <?php if ($errors->has('precio')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('precio'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="precio" required autocomplete="precio">

              <?php if ($errors->has('precio')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('precio'); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
          </div>
          <div class="form-group row mb-0">
              <div class="col-md-6 offset-md-4">
                  <button type="submit" class="btn btn-primary" value="agregarArticulo">
                      <?php echo e(__('AGREGAR')); ?>

                  </button>
              </div>
          </div>
          </div>
      </div>
    </form>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BigFashion\resources\views/modificar.blade.php ENDPATH**/ ?>